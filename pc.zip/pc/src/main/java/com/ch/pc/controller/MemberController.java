package com.ch.pc.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ch.pc.model.Member1;
import com.ch.pc.service.MemberService;

@Controller
public class MemberController {
	@Autowired
	private MemberService ms;
 
	@RequestMapping("main")
	public String main() {
		return "/main/main";
	}
	@RequestMapping("joinForm")
	public String joinForm() {
		return "/member/joinForm";
	}
	@RequestMapping("join")
	public String join(Member1 member1, Model model) {
		int result = 0;
		// form에서 입력한 member1데이터를 가져와서 member2 객체에 대입하여 아이디가 존재하는지 확인
		Member1 member2 = ms.select1(member1.getId());
		if (member2 == null) {
			result = ms.insert(member1);
		} else {
			result = -1; // 아이디 중복
		}
		model.addAttribute("result", result);
		return "member/join";
	}
	@RequestMapping(value = "confirmId", produces = "text/html;charset=utf-8") 
	@ResponseBody
	public String confirmId(String id) {
		String msg = "";
		Member1 member1 = ms.select1(id); 
		if (member1 == null) msg = "1";
		else msg = "0";
		return msg;
	}
	@RequestMapping(value = "confirmNick_name", produces = "text/html;charset=utf-8") 
	@ResponseBody
	public String confirmNick_name(String nick_name) {
		String msg = "";
		Member1 member1 = ms.select2(nick_name); 
		if (member1 == null) msg = "1";
		else msg = "0";
		return msg;
	}
	@RequestMapping(value = "confirmEmail", produces = "text/html;charset=utf-8") 
	@ResponseBody
	public String confirmEmail(String email) {
		String msg = "";
		Member1 member1 = ms.select3(email); 
		if (member1 == null) msg = "1";
		else msg = "0";
		return msg;
	}
	@RequestMapping("loginForm")
	public String loginForm() {
		return "/member/loginForm";
	}
	@RequestMapping("login")
	public String login(Member1 member1, HttpSession session, Model model) {
		Member1 member2 = ms.select1(member1.getId());
		int result = 0; // 암호가 일치하지 않는 경우
		if (member2 == null || member2.getDel().equals("y")) {
			result = -1; // DB에 없는 아이디
		}
		else if (member2.getPassword().equals(member1.getPassword())) {
			result = 1;
			session.setAttribute("id", member1.getId());
			session.setAttribute("mno", member2.getMno());
			session.setAttribute("nick_name", member2.getNick_name());	// header출력용
		}
		model.addAttribute("result", result);
		return "/member/login";
	}
	@RequestMapping("logout")
	public String logout(HttpSession session) {
		session.invalidate();
		return "/member/logout";
	}
	@RequestMapping("mypageForm")
	public String mypageForm() {
		return "/member/mypageForm";
	}
	@RequestMapping("passChkForm")
	public String passChkForm() {
		return "/member/passChkForm";
	}
	@RequestMapping("passChk")
	public String passChk(Member1 member1, HttpSession session, Model model) {
		String id = (String)session.getAttribute("id");
		Member1 member2 = ms.select1(id);
		int result = 0;
		if (member2.getPassword().equals(member1.getPassword())) {
			result = 1;
		}
		model.addAttribute("result", result);
		return "/member/passChk";
	}
	@RequestMapping("updateForm")
	public String updateForm(Model model, HttpSession session) {
		String id = (String)session.getAttribute("id");
		Member1 member = ms.select1(id);
		model.addAttribute("member", member);
		return "/member/updateForm";
	}
	@RequestMapping(value = "confirmNick_name2", produces = "text/html;charset=utf-8") 
	@ResponseBody
	public String confirmNick_name2(String nick_name, HttpSession session) {
		String id = (String)session.getAttribute("id");
		Member1 member = ms.select1(id);
		String nick_name1 = member.getNick_name();
		String msg = "";
		Member1 member1 = ms.select2(nick_name); 
		if (member1 == null) msg = "1";
		else if (member1.getNick_name().equals(nick_name1)) msg = "1";
		else msg = "0";
		System.out.println(member1.getNick_name());
		return msg;
	}
	@RequestMapping(value = "confirmEmail2", produces = "text/html;charset=utf-8") 
	@ResponseBody
	public String confirmEmail2(String email, HttpSession session) {
		String id = (String)session.getAttribute("id");
		Member1 member = ms.select1(id);
		String email1 = member.getEmail();
		String msg = "";
		Member1 member1 = ms.select3(email); 
		if (member1 == null) msg = "1";
		else if (member1.getEmail().equals(email1)) msg = "1";
		else msg = "0";
		return msg;
	}
	@RequestMapping("update")
	public String update(Member1 member1, Model model) {
		int result = 0;
		// form에서 입력한 member1데이터를 가져와서 member2 객체에 대입하여 아이디가 존재하는지 확인
		Member1 member2 = ms.select1(member1.getId());
		if (member2 == null) {
			result = -1;	// 회원정보 없음
		} else {
			result = ms.update(member1);
		}
		model.addAttribute("result", result);
		return "member/update";
	}
}
