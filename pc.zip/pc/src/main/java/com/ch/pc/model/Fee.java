package com.ch.pc.model;


public class Fee {
	private int feeno;
	private int w1000;
	private int w3000;
	private int w5000;
	private int w10000;
	private int w50000;
	private int w100000;
	public int getFeeno() {
		return feeno;
	}
	public void setFeeno(int feeno) {
		this.feeno = feeno;
	}
	public int getW1000() {
		return w1000;
	}
	public void setW1000(int w1000) {
		this.w1000 = w1000;
	}
	public int getW3000() {
		return w3000;
	}
	public void setW3000(int w3000) {
		this.w3000 = w3000;
	}
	public int getW5000() {
		return w5000;
	}
	public void setW5000(int w5000) {
		this.w5000 = w5000;
	}
	public int getW10000() {
		return w10000;
	}
	public void setW10000(int w10000) {
		this.w10000 = w10000;
	}
	public int getW50000() {
		return w50000;
	}
	public void setW50000(int w50000) {
		this.w50000 = w50000;
	}
	public int getW100000() {
		return w100000;
	}
	public void setW100000(int w100000) {
		this.w100000 = w100000;
	}
}
