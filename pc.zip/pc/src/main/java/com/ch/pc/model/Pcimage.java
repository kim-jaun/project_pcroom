package com.ch.pc.model;

public class Pcimage {
		private int imageno;
		private int pcno;
		private String imagename;
		public int getImageno() {
			return imageno;
		}
		public void setImageno(int imageno) {
			this.imageno = imageno;
		}
		public int getPcno() {
			return pcno;
		}
		public void setPcno(int pcno) {
			this.pcno = pcno;
		}
		public String getImagename() {
			return imagename;
		}
		public void setImagename(String imagename) {
			this.imagename = imagename;
		}
}
