package com.ch.pc.model;

public class Seat {
	private int seatno;
	private String seatposition;
	private int pcno;
	public int getSeatno() {
		return seatno;
	}
	public void setSeatno(int seatno) {
		this.seatno = seatno;
	}
	public String getSeatposition() {
		return seatposition;
	}
	public void setSeatposition(String seatposition) {
		this.seatposition = seatposition;
	}
	public int getPcno() {
		return pcno;
	}
	public void setPcno(int pcno) {
		this.pcno = pcno;
	}
}
