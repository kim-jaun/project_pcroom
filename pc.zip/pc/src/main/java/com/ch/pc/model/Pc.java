package com.ch.pc.model;


public class Pc {
	private int pcno;
	private String pcname;
	private String pcaddr;
	private String pcimage;
	private int pclikes;
	private String pcinfo;
	private int mno;
	private int feeno;
	public int getPcno() {
		return pcno;
	}
	public void setPcno(int pcno) {
		this.pcno = pcno;
	}
	public String getPcname() {
		return pcname;
	}
	public void setPcname(String pcname) {
		this.pcname = pcname;
	}
	public String getPcaddr() {
		return pcaddr;
	}
	public void setPcaddr(String pcaddr) {
		this.pcaddr = pcaddr;
	}
	public String getPcimage() {
		return pcimage;
	}
	public void setPcimage(String pcimage) {
		this.pcimage = pcimage;
	}
	public int getPclikes() {
		return pclikes;
	}
	public void setPclikes(int pclikes) {
		this.pclikes = pclikes;
	}
	public String getPcinfo() {
		return pcinfo;
	}
	public void setPcinfo(String pcinfo) {
		this.pcinfo = pcinfo;
	}
	public int getMno() {
		return mno;
	}
	public void setMno(int mno) {
		this.mno = mno;
	}
	public int getFeeno() {
		return feeno;
	}
	public void setFeeno(int feeno) {
		this.feeno = feeno;
	}
	
}
