package com.ch.pc.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ch.pc.dao.MemberDao;
import com.ch.pc.model.Member1;

@Service
public class MemberServiceImpl implements MemberService {
	@Autowired
	private MemberDao md;
	
	public int insert(Member1 member1) {
		return md.insert(member1);
	}
	public Member1 select1(String id) {
		return md.select1(id);
	}
	public Member1 select2(String nick_name) {
		return md.select2(nick_name);
	}
	public Member1 select3(String email) {
		return md.select3(email);
	}
	@Override
	public int update(Member1 member1) {
		return md.update(member1);
	}
}
