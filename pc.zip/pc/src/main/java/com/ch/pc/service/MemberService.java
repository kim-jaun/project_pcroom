package com.ch.pc.service;

import com.ch.pc.model.Member1;

public interface MemberService {

	int insert(Member1 member1);
	
	Member1 select1(String id);
	
	Member1 select2(String nick_name);

	Member1 select3(String email);

	int update(Member1 member1);


}
