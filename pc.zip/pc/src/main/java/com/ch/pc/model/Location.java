package com.ch.pc.model;


public class Location {	
	private String sido;
	private String sigugun;
	private String dong;
	public String getSido() {
		return sido;
	}
	public void setSido(String sido) {
		this.sido = sido;
	}
	public String getSigugun() {
		return sigugun;
	}
	public void setSigugun(String sigugun) {
		this.sigugun = sigugun;
	}
	public String getDong() {
		return dong;
	}
	public void setDong(String dong) {
		this.dong = dong;
	}
}
