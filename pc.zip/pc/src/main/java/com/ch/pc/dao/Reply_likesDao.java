package com.ch.pc.dao;

public interface Reply_likesDao {

}
