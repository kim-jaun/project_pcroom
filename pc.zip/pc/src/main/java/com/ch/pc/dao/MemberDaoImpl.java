package com.ch.pc.dao;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ch.pc.model.Member1;

@Repository
public class MemberDaoImpl implements MemberDao {
	@Autowired
	private SqlSessionTemplate sst;

	public int insert(Member1 member1) {
		return sst.insert("member1ns.insert", member1);
	}
	public Member1 select1(String id) {
		return sst.selectOne("member1ns.confirmId",id);
	}
	public Member1 select2(String nick_name) {
		return sst.selectOne("member1ns.confirmNick_name", nick_name);
	}
	public Member1 select3(String email) {
		return sst.selectOne("member1ns.confirmEmail", email);
	}
	public int update(Member1 member1) {
		return sst.update("member1ns.update", member1);
	}

}
