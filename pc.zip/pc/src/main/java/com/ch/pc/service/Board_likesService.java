package com.ch.pc.service;

public interface Board_likesService {

	int select(int mno, int bno);

	void delete(int mno, int bno);

	void insert(int mno, int bno);

}
